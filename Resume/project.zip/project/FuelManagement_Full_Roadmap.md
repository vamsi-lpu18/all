# ⛽ Indian Fuel Management System — Complete Roadmap & Diagrams

---

## 📋 Table of Contents

1. [Functional Requirements](#1-functional-requirements)
2. [Use Case Diagram](#2-use-case-diagram)
3. [Sequence Diagrams](#3-sequence-diagrams)
4. [Class Diagram](#4-class-diagram)
5. [ER Diagram](#5-er-diagram)
6. [System Architecture](#6-system-architecture)
7. [Component Diagram](#7-component-diagram)
8. [Activity Diagram](#8-activity-diagrams)
9. [Sprint Roadmap](#9-detailed-sprint-roadmap)
10. [Page Designs](#10-page-designs--wireframes)
11. [API Flow Diagram](#11-api-flow-diagram)
12. [Deployment Diagram](#12-deployment-diagram)

---

## 1. Functional Requirements

### FR-1: Authentication & Authorization

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-1.1 | User can register with email, password, name, phone | High | All |
| FR-1.2 | User can login and receive JWT token | High | All |
| FR-1.3 | System assigns roles: Customer, Dealer, Admin | High | System |
| FR-1.4 | JWT token contains userId, role, stationId | High | System |
| FR-1.5 | Token expires after 8 hours | Medium | System |
| FR-1.6 | Admin can assign roles to users | Medium | Admin |
| FR-1.7 | Protected routes check JWT at Gateway level | High | System |

### FR-2: Fuel Station Management

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-2.1 | Admin can create new fuel stations | High | Admin |
| FR-2.2 | Admin can assign dealer to a station | High | Admin |
| FR-2.3 | Anyone can view station list with fuel prices | High | All |
| FR-2.4 | Station details include: name, address, city, license | High | All |
| FR-2.5 | Admin can deactivate a station | Medium | Admin |
| FR-2.6 | Filter stations by city | Low | All |

### FR-3: Fuel Inventory Management

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-3.1 | Each station has Petrol and Diesel tanks | High | System |
| FR-3.2 | Dealer can view current fuel stock levels | High | Dealer |
| FR-3.3 | Dealer can record fuel refill (delivery from supplier) | High | Dealer |
| FR-3.4 | Refill records supplier name and invoice number | High | Dealer |
| FR-3.5 | System prevents overfilling beyond tank capacity | High | System |
| FR-3.6 | System sends LOW STOCK alert when below 500 liters | High | System |
| FR-3.7 | Admin can view stock levels of all stations | High | Admin |

### FR-4: Fuel Sales

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-4.1 | Dealer can record a fuel sale | High | Dealer |
| FR-4.2 | Sale includes: fuel type, liters, vehicle number, payment method | High | Dealer |
| FR-4.3 | System auto-calculates total amount | High | System |
| FR-4.4 | System checks stock before confirming sale (Saga) | High | System |
| FR-4.5 | Sale starts as "Pending" → becomes "Completed" or "Failed" | High | System |
| FR-4.6 | If stock insufficient → sale is cancelled (compensation) | High | System |
| FR-4.7 | Each sale generates a unique receipt number | High | System |
| FR-4.8 | Customer can view their transaction history | Medium | Customer |

### FR-5: Reports & Analytics

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-5.1 | System generates daily sales report per station | High | Admin |
| FR-5.2 | Admin can view total revenue for date range | High | Admin |
| FR-5.3 | Admin can see fuel-wise breakdown (Petrol vs Diesel) | Medium | Admin |
| FR-5.4 | Admin can export reports | Low | Admin |

### FR-6: Fraud Detection

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-6.1 | System detects stock mismatch (sold > available) | High | System |
| FR-6.2 | System flags unusual sales patterns | Medium | System |
| FR-6.3 | Admin can view fraud alerts | High | Admin |
| FR-6.4 | Admin can mark alerts as resolved | Medium | Admin |

### FR-7: Notifications

| ID | Requirement | Priority | Role |
|----|------------|----------|------|
| FR-7.1 | Notify dealer when sale is completed | High | System |
| FR-7.2 | Notify admin on low stock | High | System |
| FR-7.3 | Notify admin on fraud detection | High | System |
| FR-7.4 | Notify dealer when sale fails | High | System |

### Non-Functional Requirements

| ID | Requirement | Target |
|----|------------|--------|
| NFR-1 | Response time < 500ms for API calls | Performance |
| NFR-2 | Rate limiting: 20-100 requests/min per route | Security |
| NFR-3 | System handles 100 concurrent users | Scalability |
| NFR-4 | 99.9% uptime | Availability |
| NFR-5 | All passwords hashed (bcrypt) | Security |
| NFR-6 | Code quality score > 80% on SonarQube | Quality |
| NFR-7 | Test coverage > 80% | Quality |

---

## 2. Use Case Diagram

```mermaid
graph TB
    subgraph "Indian Fuel Management System"
        UC1["Register / Login"]
        UC2["View Fuel Prices"]
        UC3["View Transaction History"]
        UC4["Record Fuel Sale"]
        UC5["View Station Stock"]
        UC6["Refill Fuel Stock"]
        UC7["View Station Dashboard"]
        UC8["Create Station"]
        UC9["Manage Users"]
        UC10["View Reports"]
        UC11["View Fraud Alerts"]
        UC12["Monitor All Stations"]
        UC13["Check Stock via Saga"]
        UC14["Send Notifications"]
        UC15["Detect Fraud"]
    end

    CUST["🧑 Customer"]
    DEALER["👷 Dealer"]
    ADMIN["👔 Admin"]
    SYS["⚙️ System"]

    CUST --> UC1
    CUST --> UC2
    CUST --> UC3

    DEALER --> UC1
    DEALER --> UC4
    DEALER --> UC5
    DEALER --> UC6
    DEALER --> UC7

    ADMIN --> UC1
    ADMIN --> UC8
    ADMIN --> UC9
    ADMIN --> UC10
    ADMIN --> UC11
    ADMIN --> UC12

    SYS --> UC13
    SYS --> UC14
    SYS --> UC15
```

---

## 3. Sequence Diagrams

### 3a. Login Sequence

```mermaid
sequenceDiagram
    actor User
    participant React as React Frontend
    participant GW as Ocelot Gateway
    participant Auth as Identity Service
    participant DB as AuthDB

    User->>React: Enter email & password
    React->>GW: POST /api/auth/login
    GW->>GW: Check rate limit (20/min)
    GW->>Auth: Forward to Auth Service
    Auth->>DB: Find user by email
    DB-->>Auth: User found
    Auth->>Auth: Verify password hash
    Auth->>Auth: Generate JWT token
    Auth-->>GW: 200 OK {token, user}
    GW-->>React: 200 OK {token, user}
    React->>React: Store token in localStorage
    React-->>User: Redirect to Dashboard
```

### 3b. Fuel Sale SAGA Sequence (Most Important!)

```mermaid
sequenceDiagram
    actor Dealer
    participant React as React Frontend
    participant GW as Ocelot Gateway
    participant Sales as Sales Service
    participant RMQ as RabbitMQ
    participant Fuel as Fuel Service
    participant Notify as Notification Svc

    Dealer->>React: Enter sale details
    React->>GW: POST /api/sales {fuelType, liters, vehicle}
    GW->>GW: Validate JWT + Check rate limit
    GW->>Sales: Forward request

    Sales->>Sales: Create sale (status: Pending)
    Sales->>RMQ: Publish SaleCreatedEvent

    RMQ->>Fuel: Deliver SaleCreatedEvent
    Fuel->>Fuel: Check stock levels

    alt Enough Stock ✅
        Fuel->>Fuel: Deduct liters from tank
        Fuel->>RMQ: Publish StockDeductedEvent
        RMQ->>Sales: Deliver StockDeductedEvent
        Sales->>Sales: Update sale → "Completed" ✅
        Sales->>RMQ: Publish SaleCompletedEvent
        RMQ->>Notify: Deliver SaleCompletedEvent
        Notify->>Notify: Log "Sale confirmed" alert
    else Not Enough Stock ❌
        Fuel->>RMQ: Publish StockInsufficientEvent
        RMQ->>Sales: Deliver StockInsufficientEvent
        Sales->>Sales: Update sale → "Failed" ❌ (COMPENSATION)
        Sales->>RMQ: Publish SaleCancelledEvent
        RMQ->>Notify: Deliver SaleCancelledEvent
        Notify->>Notify: Log "Sale failed" alert
    end

    Sales-->>GW: 200 OK {sale}
    GW-->>React: 200 OK {sale}
    React-->>Dealer: Show sale status
```

### 3c. Fuel Refill Sequence

```mermaid
sequenceDiagram
    actor Dealer
    participant React as React Frontend
    participant GW as Ocelot Gateway
    participant Fuel as Fuel Service
    participant DB as FuelDB
    participant RMQ as RabbitMQ
    participant Notify as Notification Svc

    Dealer->>React: Enter refill details
    React->>GW: PUT /api/fuel-stock/{stationId}/refill
    GW->>GW: Validate JWT (Dealer role)
    GW->>Fuel: Forward request

    Fuel->>DB: Find fuel stock
    Fuel->>Fuel: Check tank capacity

    alt Within Capacity ✅
        Fuel->>DB: Add liters to stock
        Fuel->>DB: Save refill record
        Fuel-->>GW: 200 OK {updated stock}
    else Exceeds Capacity ❌
        Fuel-->>GW: 400 Bad Request
    end

    GW-->>React: Response
    React-->>Dealer: Show result
```

### 3d. Low Stock Alert Sequence

```mermaid
sequenceDiagram
    participant Fuel as Fuel Service
    participant RMQ as RabbitMQ
    participant Notify as Notification Svc

    Fuel->>Fuel: After stock deduction, check level
    alt Stock < 500 Liters
        Fuel->>RMQ: Publish LowStockAlertEvent
        RMQ->>Notify: Deliver alert
        Notify->>Notify: Log 🚨 "LOW STOCK" warning
        Note over Notify: In production: send SMS/Email to Admin
    end
```

---

## 4. Class Diagram

```mermaid
classDiagram
    class AppUser {
        +Guid Id
        +string FullName
        +string Email
        +string PasswordHash
        +string PhoneNumber
        +Guid? StationId
        +DateTime CreatedAt
    }

    class Station {
        +Guid Id
        +string Name
        +string Address
        +string City
        +string State
        +string LicenseNumber
        +Guid? DealerId
        +bool IsActive
        +DateTime CreatedAt
    }

    class FuelStock {
        +Guid Id
        +Guid StationId
        +string FuelType
        +double CurrentLiters
        +double TankCapacity
        +decimal PricePerLiter
        +DateTime LastRefillDate
        +DateTime UpdatedAt
    }

    class FuelRefill {
        +Guid Id
        +Guid StationId
        +string FuelType
        +double LitersAdded
        +string SupplierName
        +string InvoiceNumber
        +DateTime RefilledAt
    }

    class FuelSale {
        +Guid Id
        +Guid StationId
        +string FuelType
        +double Liters
        +decimal PricePerLiter
        +decimal TotalAmount
        +string PaymentMethod
        +string VehicleNumber
        +string Status
        +string ReceiptNumber
        +DateTime CreatedAt
    }

    class DailyReport {
        +Guid Id
        +Guid StationId
        +DateTime Date
        +double TotalPetrolSold
        +double TotalDieselSold
        +decimal TotalRevenue
        +double OpeningStock
        +double ClosingStock
    }

    class FraudAlert {
        +Guid Id
        +Guid StationId
        +string AlertType
        +string Description
        +string Severity
        +bool IsResolved
        +DateTime DetectedAt
    }

    AppUser "1" --> "0..1" Station : manages
    Station "1" --> "*" FuelStock : has
    Station "1" --> "*" FuelRefill : receives
    Station "1" --> "*" FuelSale : records
    Station "1" --> "*" DailyReport : generates
    Station "1" --> "*" FraudAlert : triggers
    FuelStock "1" --> "1" Station : belongs to
```

---

## 5. ER Diagram

```mermaid
erDiagram
    USERS {
        guid Id PK
        string FullName
        string Email UK
        string PasswordHash
        string PhoneNumber
        guid StationId FK
        string Role
        datetime CreatedAt
    }

    STATIONS {
        guid Id PK
        string Name
        string Address
        string City
        string State
        string LicenseNumber UK
        guid DealerId FK
        bool IsActive
        datetime CreatedAt
    }

    FUEL_STOCK {
        guid Id PK
        guid StationId FK
        string FuelType
        double CurrentLiters
        double TankCapacity
        decimal PricePerLiter
        datetime LastRefillDate
        datetime UpdatedAt
    }

    FUEL_REFILLS {
        guid Id PK
        guid StationId FK
        string FuelType
        double LitersAdded
        string SupplierName
        string InvoiceNumber
        datetime RefilledAt
    }

    FUEL_SALES {
        guid Id PK
        guid StationId FK
        string FuelType
        double Liters
        decimal PricePerLiter
        decimal TotalAmount
        string PaymentMethod
        string VehicleNumber
        string Status
        string ReceiptNumber UK
        datetime CreatedAt
    }

    DAILY_REPORTS {
        guid Id PK
        guid StationId FK
        date Date
        double TotalPetrolSold
        double TotalDieselSold
        decimal TotalRevenue
        double OpeningStock
        double ClosingStock
        datetime GeneratedAt
    }

    FRAUD_ALERTS {
        guid Id PK
        guid StationId FK
        string AlertType
        string Description
        string Severity
        bool IsResolved
        datetime DetectedAt
    }

    USERS ||--o| STATIONS : "manages (dealer)"
    STATIONS ||--o{ FUEL_STOCK : "has"
    STATIONS ||--o{ FUEL_REFILLS : "receives"
    STATIONS ||--o{ FUEL_SALES : "records"
    STATIONS ||--o{ DAILY_REPORTS : "generates"
    STATIONS ||--o{ FRAUD_ALERTS : "triggers"
```

---

## 6. System Architecture

```mermaid
graph TB
    subgraph "Client Layer"
        REACT["React 18 App<br/>Vite + TypeScript"]
    end

    subgraph "API Gateway Layer"
        OCELOT["Ocelot API Gateway<br/>Port 5000<br/>• JWT Validation<br/>• Rate Limiting<br/>• Load Balancing<br/>• Request Routing"]
    end

    subgraph "Microservices Layer"
        AUTH["Identity Service<br/>Port 5001<br/>• Register/Login<br/>• JWT Generation<br/>• Role Management"]
        FUEL["Fuel Service<br/>Port 5002<br/>• Station CRUD<br/>• Stock Management<br/>• Refill Recording<br/>• Stock Check Consumer"]
        SALES["Sales Service<br/>Port 5003<br/>• Record Sales<br/>• Saga Initiator<br/>• Receipt Generation<br/>• Confirm/Cancel Consumers"]
        ADMIN["Admin Service<br/>Port 5004<br/>• Daily Reports<br/>• Revenue Analytics<br/>• Fraud Detection<br/>• Report Consumer"]
        NOTIFY["Notification Service<br/>Background Worker<br/>• Sale Alerts<br/>• Low Stock Alerts<br/>• Fraud Alerts"]
    end

    subgraph "Messaging Layer"
        RMQ["RabbitMQ<br/>Port 5672 (AMQP)<br/>Port 15672 (Dashboard)<br/>• Event Queues<br/>• Message Retry"]
    end

    subgraph "Data Layer (DB per Service)"
        DB1[("AuthDB<br/>SQL Server<br/>• Users<br/>• Roles")]
        DB2[("FuelDB<br/>PostgreSQL<br/>• Stations<br/>• FuelStock<br/>• Refills")]
        DB3[("SalesDB<br/>PostgreSQL<br/>• FuelSales")]
        DB4[("AdminDB<br/>PostgreSQL<br/>• Reports<br/>• FraudAlerts")]
    end

    subgraph "DevOps Layer"
        DOCKER["Docker + Docker Compose"]
        CICD["GitHub Actions CI/CD"]
        SONAR["SonarQube"]
    end

    REACT -->|"HTTP/HTTPS"| OCELOT
    OCELOT --> AUTH
    OCELOT --> FUEL
    OCELOT --> SALES
    OCELOT --> ADMIN

    AUTH --> DB1
    FUEL --> DB2
    SALES --> DB3
    ADMIN --> DB4

    FUEL <-->|"Events"| RMQ
    SALES <-->|"Events"| RMQ
    ADMIN <-->|"Events"| RMQ
    NOTIFY -->|"Listens"| RMQ
```

---

## 7. Component Diagram

```mermaid
graph LR
    subgraph "React Frontend"
        AUTH_CTX["AuthContext<br/>(Login State)"]
        API_SVC["api.ts<br/>(Axios + JWT)"]
        PAGES["Pages<br/>Login | Customer<br/>Dealer | Admin"]
        GUARDS["ProtectedRoute<br/>(Route Guards)"]
    end

    subgraph "Identity Service"
        AUTH_CTRL["AuthController"]
        AUTH_SVC2["AuthService"]
        JWT_GEN["JWT Generator"]
        USER_MGR["UserManager"]
        AUTH_DB_CTX["AuthDbContext"]
    end

    subgraph "Fuel Service"
        STATION_CTRL["StationsController"]
        STOCK_CTRL["FuelStockController"]
        SALE_CONSUMER["SaleCreatedConsumer"]
        FUEL_DB_CTX["FuelDbContext"]
    end

    subgraph "Sales Service"
        SALES_CTRL["SalesController"]
        STOCK_OK["StockDeductedConsumer"]
        STOCK_FAIL["StockInsufficientConsumer"]
        SALES_DB_CTX["SalesDbContext"]
    end

    PAGES --> API_SVC
    API_SVC -->|"HTTP"| AUTH_CTRL
    API_SVC -->|"HTTP"| STATION_CTRL
    API_SVC -->|"HTTP"| SALES_CTRL

    AUTH_CTRL --> AUTH_SVC2
    AUTH_SVC2 --> JWT_GEN
    AUTH_SVC2 --> USER_MGR
    USER_MGR --> AUTH_DB_CTX

    SALES_CTRL -->|"Publish"| SALE_CONSUMER
    SALE_CONSUMER -->|"Publish"| STOCK_OK
    SALE_CONSUMER -->|"Publish"| STOCK_FAIL
```

---

## 8. Activity Diagrams

### 8a. Fuel Sale Activity

```mermaid
flowchart TD
    A["Dealer opens Sale Form"] --> B["Enter: FuelType, Liters, Vehicle, Payment"]
    B --> C["Click 'Record Sale'"]
    C --> D["Sales Service: Create sale - Pending"]
    D --> E["Publish SaleCreatedEvent to RabbitMQ"]
    E --> F["Fuel Service: Receive event"]
    F --> G{"Enough stock?"}
    G -->|"Yes ✅"| H["Deduct liters from tank"]
    H --> I["Publish StockDeductedEvent"]
    I --> J["Sales Service: Update sale → Completed"]
    J --> K["Publish SaleCompletedEvent"]
    K --> L["Notification: Alert dealer"]
    L --> M["Show receipt to dealer ✅"]

    G -->|"No ❌"| N["Publish StockInsufficientEvent"]
    N --> O["Sales Service: Update sale → Failed"]
    O --> P["Publish SaleCancelledEvent"]
    P --> Q["Notification: Alert dealer"]
    Q --> R["Show error to dealer ❌"]

    H --> S{"Stock < 500L?"}
    S -->|"Yes"| T["Publish LowStockAlertEvent"]
    T --> U["Notification: Alert admin 🚨"]
    S -->|"No"| V["Continue normally"]
```

### 8b. Fuel Refill Activity

```mermaid
flowchart TD
    A["Dealer opens Refill Form"] --> B["Enter: FuelType, Liters, Supplier, Invoice"]
    B --> C["Click 'Add Refill'"]
    C --> D{"Liters + Current <= Tank Capacity?"}
    D -->|"Yes ✅"| E["Add liters to stock"]
    E --> F["Save refill record"]
    F --> G["Show updated stock ✅"]
    D -->|"No ❌"| H["Show error: Exceeds capacity ❌"]
```

---

## 9. Detailed Sprint Roadmap

```mermaid
gantt
    title Fuel Management System — 6 Week Roadmap
    dateFormat  YYYY-MM-DD
    axisFormat  %b %d

    section Sprint 1: Foundation
    Create solution & projects     :s1a, 2024-01-01, 2d
    Install NuGet packages         :s1b, after s1a, 1d
    Shared library (events + DTOs) :s1c, after s1b, 2d
    Identity Service (Auth + JWT)  :s1d, after s1c, 2d

    section Sprint 2: Fuel Service
    Station & FuelStock models     :s2a, after s1d, 2d
    FuelDbContext + migrations     :s2b, after s2a, 1d
    Stations & FuelStock APIs      :s2c, after s2b, 2d
    SaleCreatedConsumer (Saga)     :s2d, after s2c, 2d

    section Sprint 3: Sales + Saga
    FuelSale model + SalesDb       :s3a, after s2d, 2d
    SalesController + receipt      :s3b, after s3a, 2d
    Saga consumers (confirm/cancel):s3c, after s3b, 2d
    Test full saga flow            :s3d, after s3c, 1d

    section Sprint 4: Admin + Gateway
    Admin Service + Reports        :s4a, after s3d, 2d
    Notification Service           :s4b, after s4a, 1d
    Ocelot Gateway + Rate Limiting :s4c, after s4b, 2d
    Integration testing            :s4d, after s4c, 2d

    section Sprint 5: React Frontend
    React setup + Auth pages       :s5a, after s4d, 2d
    Customer & Dealer dashboards   :s5b, after s5a, 2d
    Admin dashboard + Reports      :s5c, after s5b, 2d
    Polish UI + Charts             :s5d, after s5c, 1d

    section Sprint 6: DevOps
    Dockerfiles for each service   :s6a, after s5d, 2d
    Docker Compose (full stack)    :s6b, after s6a, 1d
    GitHub Actions CI/CD           :s6c, after s6b, 1d
    SonarQube + Tests              :s6d, after s6c, 2d
    Documentation + Diagrams       :s6e, after s6d, 1d
```

---

## 10. Page Designs / Wireframes

### 10a. Page Layout Structure

```
┌─────────────────────────────────────────┐
│  🔥 Indian Fuel Management System       │
│  ┌──────┐  ┌────────────────────────┐   │
│  │SIDE  │  │                        │   │
│  │BAR   │  │     MAIN CONTENT       │   │
│  │      │  │                        │   │
│  │📊 Dash│  │  (changes per page)   │   │
│  │⛽ Stock│  │                        │   │
│  │💰 Sales│  │                        │   │
│  │📋 Report│  │                        │   │
│  │⚙️ Admin│  │                        │   │
│  └──────┘  └────────────────────────┘   │
└─────────────────────────────────────────┘
```

### 10b. Page Descriptions

**Login Page (`/login`)**
```
┌──────────────────────────────────┐
│      ⛽ Fuel Management System    │
│                                  │
│  ┌────────────────────────────┐  │
│  │  Email: [______________]   │  │
│  │  Password: [___________]   │  │
│  │                            │  │
│  │  [    LOGIN BUTTON     ]   │  │
│  │                            │  │
│  │  Don't have account?       │  │
│  │  Register →                │  │
│  └────────────────────────────┘  │
└──────────────────────────────────┘
```

**Dealer Dashboard (`/dealer`)**
```
┌──────────────────────────────────────────┐
│  Welcome, Rajesh (Dealer)    [Logout]    │
├──────────────────────────────────────────┤
│                                          │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐   │
│  │PETROL│ │DIESEL│ │SALES │ │REVENUE│  │
│  │5000L │ │8000L │ │  42  │ │₹1.2L  │  │
│  └──────┘ └──────┘ └──────┘ └──────┘   │
│                                          │
│  [Record Sale]  [Refill Stock]           │
│                                          │
│  Recent Sales:                           │
│  ┌────┬────────┬───────┬───────┬──────┐ │
│  │Time│FuelType│ Liters│Amount │Status│ │
│  ├────┼────────┼───────┼───────┼──────┤ │
│  │9:30│Petrol  │  10L  │₹1035 │ ✅   │ │
│  │9:15│Diesel  │  20L  │₹1795 │ ✅   │ │
│  │9:00│Petrol  │  50L  │₹5175 │ ❌   │ │
│  └────┴────────┴───────┴───────┴──────┘ │
└──────────────────────────────────────────┘
```

**Record Sale Page (`/dealer/sell`)**
```
┌────────────────────────────────────┐
│  ⛽ Record Fuel Sale               │
│                                    │
│  Fuel Type:  [Petrol ▼]           │
│  Liters:     [________]           │
│  Vehicle:    [KA-01-AB-1234]      │
│  Payment:    [Cash ▼]             │
│                                    │
│  Price/L: ₹103.50                  │
│  Total:   ₹1,035.00               │
│                                    │
│  [   RECORD SALE   ]              │
│                                    │
│  Status: ⏳ Pending...             │
│  → ✅ Sale Confirmed! Receipt: RCP-20240319-A1B2C3
└────────────────────────────────────┘
```

**Admin Dashboard (`/admin`)**
```
┌──────────────────────────────────────────┐
│  Admin Dashboard               [Logout]  │
├──────────────────────────────────────────┤
│                                          │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐   │
│  │TOTAL │ │TOTAL │ │TODAY │ │FRAUD │   │
│  │STNS  │ │SALES │ │REV   │ │ALERTS│   │
│  │  12  │ │ 340  │ │₹4.5L │ │  3   │   │
│  └──────┘ └──────┘ └──────┘ └──────┘   │
│                                          │
│  ┌─────────────────────────────────┐     │
│  │  📊 Revenue Chart (last 7 days) │     │
│  │  ▓▓▓▓▓▓░░                      │     │
│  │  ▓▓▓▓▓▓▓▓░░                    │     │
│  │  ▓▓▓▓░░                        │     │
│  └─────────────────────────────────┘     │
│                                          │
│  🚨 Fraud Alerts:                        │
│  • HP Pump MG Road: Stock mismatch [!]   │
│  • BPCL Whitefield: Unusual sale [!]     │
└──────────────────────────────────────────┘
```

---

## 11. API Flow Diagram

```mermaid
flowchart LR
    subgraph "React Frontend :3000"
        R["All API calls"]
    end

    subgraph "Ocelot Gateway :5000"
        GW["Route + Auth + Rate Limit"]
    end

    subgraph "Services"
        A1["/api/auth/* → Identity :5001"]
        A2["/api/stations/* → Fuel :5002"]
        A3["/api/fuel-stock/* → Fuel :5002"]
        A4["/api/sales/* → Sales :5003"]
        A5["/api/reports/* → Admin :5004"]
        A6["/api/fraud-alerts/* → Admin :5004"]
    end

    R -->|"All requests"| GW
    GW --> A1
    GW --> A2
    GW --> A3
    GW --> A4
    GW --> A5
    GW --> A6
```

---

## 12. Deployment Diagram

```mermaid
graph TB
    subgraph "Developer Machine"
        DEV["VS Code + .NET SDK + Node.js"]
    end

    subgraph "Docker Compose (Development)"
        subgraph "Infrastructure"
            SQL["SQL Server :1433"]
            PG1["PostgreSQL :5432 (Fuel)"]
            PG2["PostgreSQL :5433 (Sales)"]
            PG3["PostgreSQL :5434 (Admin)"]
            RABBIT["RabbitMQ :5672/:15672"]
            SONAR["SonarQube :9000"]
        end

        subgraph "Application"
            GW2["API Gateway :5000"]
            S1["Identity Svc"]
            S2["Fuel Svc"]
            S3["Sales Svc"]
            S4["Admin Svc"]
            S5["Notification Worker"]
            FE["React App :3000"]
        end
    end

    subgraph "CI/CD Pipeline"
        GH["GitHub Repository"]
        GA["GitHub Actions"]
        DH["Docker Hub"]
    end

    DEV -->|"git push"| GH
    GH -->|"trigger"| GA
    GA -->|"build + test + scan"| SONAR
    GA -->|"docker push"| DH

    FE --> GW2
    GW2 --> S1
    GW2 --> S2
    GW2 --> S3
    GW2 --> S4

    S1 --> SQL
    S2 --> PG1
    S3 --> PG2
    S4 --> PG3

    S2 <--> RABBIT
    S3 <--> RABBIT
    S4 <--> RABBIT
    S5 --> RABBIT
```

---

## 📝 Test Cases Summary

| # | Test Case | Input | Expected | Type |
|---|-----------|-------|----------|------|
| TC-01 | Register new user | Valid dto | 200 + JWT token | Positive |
| TC-02 | Register duplicate email | Existing email | 400 Bad Request | Negative |
| TC-03 | Login valid | Correct creds | 200 + JWT token | Positive |
| TC-04 | Login wrong password | Wrong password | 401 Unauthorized | Negative |
| TC-05 | Access protected route without token | No JWT | 401 Unauthorized | Security |
| TC-06 | Access admin route as Customer | Customer JWT | 403 Forbidden | Security |
| TC-07 | Create station as Admin | Valid dto + Admin JWT | 200 + Station | Positive |
| TC-08 | Refill within capacity | liters < capacity | 200 + Updated stock | Positive |
| TC-09 | Refill exceeds capacity | liters > remaining | 400 Bad Request | Negative |
| TC-10 | Record sale with stock | Liters < available | Sale → Completed | Saga ✅ |
| TC-11 | Record sale without stock | Liters > available | Sale → Failed | Saga ❌ |
| TC-12 | Rate limit exceeded | 25 login requests/min | 429 Too Many Requests | Rate Limit |
| TC-13 | Low stock alert | Stock < 500L after sale | LowStockAlertEvent published | Event |
| TC-14 | Daily report generation | Valid date + stationId | Report with totals | Report |

---

## ✅ Final Checklist

- [ ] Sprint 1: Solution setup + Identity Service
- [ ] Sprint 2: Fuel Service + Stock management
- [ ] Sprint 3: Sales Service + Saga pattern
- [ ] Sprint 4: Admin + Notification + Gateway
- [ ] Sprint 5: React Frontend
- [ ] Sprint 6: Docker + CI/CD + SonarQube + Tests
- [ ] UML Diagrams (Use Case, Sequence, Class, ER) ← in this document!
- [ ] README.md
- [ ] Working demo
