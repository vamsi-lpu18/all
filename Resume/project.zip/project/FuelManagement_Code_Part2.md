# ⛽ Fuel Management System — Code Part 2
# Sales Service (Saga) + Admin Service + Notification + Gateway + Docker + CI/CD

---

## SALES SERVICE (Saga Pattern)

### `src/SalesService/Models/FuelSale.cs`
```csharp
namespace FuelManagement.SalesService.Models;

public class FuelSale
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StationId { get; set; }
    public string FuelType { get; set; } = "";       // Petrol or Diesel
    public double Liters { get; set; }
    public decimal PricePerLiter { get; set; }
    public decimal TotalAmount { get; set; }
    public string PaymentMethod { get; set; } = "Cash"; // Cash, UPI, Card
    public string VehicleNumber { get; set; } = "";
    public string Status { get; set; } = "Pending";  // Pending → Completed or Failed
    public string ReceiptNumber { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
```

### `src/SalesService/Data/SalesDbContext.cs`
```csharp
using Microsoft.EntityFrameworkCore;
using FuelManagement.SalesService.Models;

namespace FuelManagement.SalesService.Data;

public class SalesDbContext : DbContext
{
    public SalesDbContext(DbContextOptions<SalesDbContext> options) : base(options) { }
    public DbSet<FuelSale> FuelSales => Set<FuelSale>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.Entity<FuelSale>(e =>
        {
            e.HasKey(s => s.Id);
            e.HasIndex(s => s.StationId);
            e.HasIndex(s => s.Status);
            e.HasIndex(s => s.ReceiptNumber).IsUnique();
            e.Property(s => s.TotalAmount).HasPrecision(10, 2);
            e.Property(s => s.PricePerLiter).HasPrecision(10, 2);
        });
    }
}
```

### `src/SalesService/Controllers/SalesController.cs`
```csharp
using System.Security.Claims;
using MassTransit;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FuelManagement.SalesService.Data;
using FuelManagement.SalesService.Models;
using FuelManagement.Shared.DTOs;
using FuelManagement.Shared.Events;

namespace FuelManagement.SalesService.Controllers;

[ApiController]
[Route("api/sales")]
[Authorize]
public class SalesController : ControllerBase
{
    private readonly SalesDbContext _db;
    private readonly IPublishEndpoint _bus;

    public SalesController(SalesDbContext db, IPublishEndpoint bus)
    {
        _db = db;
        _bus = bus;
    }

    // POST /api/sales — Dealer records a fuel sale (starts SAGA)
    [HttpPost]
    [Authorize(Roles = "Dealer,Admin")]
    public async Task<IActionResult> RecordSale([FromBody] RecordSaleDto dto)
    {
        // Get dealer's station from JWT token
        var stationClaim = User.FindFirst("StationId")?.Value;
        if (string.IsNullOrEmpty(stationClaim))
            return BadRequest(new { message = "No station assigned to this dealer" });

        var stationId = Guid.Parse(stationClaim);

        // Create sale with "Pending" status
        var sale = new FuelSale
        {
            StationId = stationId,
            FuelType = dto.FuelType,
            Liters = dto.Liters,
            PricePerLiter = dto.FuelType == "Petrol" ? 103.50m : 89.75m,
            PaymentMethod = dto.PaymentMethod,
            VehicleNumber = dto.VehicleNumber,
            Status = "Pending",
            ReceiptNumber = $"RCP-{DateTime.Now:yyyyMMdd}-{Guid.NewGuid().ToString()[..6].ToUpper()}"
        };
        sale.TotalAmount = sale.PricePerLiter * (decimal)sale.Liters;

        _db.FuelSales.Add(sale);
        await _db.SaveChangesAsync();

        // PUBLISH EVENT → RabbitMQ → Fuel Service will check stock
        await _bus.Publish(new SaleCreatedEvent
        {
            SaleId = sale.Id,
            StationId = stationId,
            FuelType = dto.FuelType,
            Liters = dto.Liters,
            TotalAmount = sale.TotalAmount,
            CreatedAt = DateTime.UtcNow
        });

        return Ok(new { message = "Sale recorded! Checking stock...", sale });
    }

    // GET /api/sales — Get sales for my station
    [HttpGet]
    public async Task<IActionResult> GetSales([FromQuery] Guid? stationId)
    {
        var query = _db.FuelSales.AsQueryable();
        if (stationId.HasValue)
            query = query.Where(s => s.StationId == stationId.Value);

        var sales = await query.OrderByDescending(s => s.CreatedAt).Take(50).ToListAsync();
        return Ok(sales);
    }

    // GET /api/sales/{id}/receipt — Get receipt
    [HttpGet("{id}/receipt")]
    public async Task<IActionResult> GetReceipt(Guid id)
    {
        var sale = await _db.FuelSales.FindAsync(id);
        if (sale == null) return NotFound();

        return Ok(new
        {
            sale.ReceiptNumber,
            sale.FuelType,
            sale.Liters,
            sale.PricePerLiter,
            sale.TotalAmount,
            sale.PaymentMethod,
            sale.VehicleNumber,
            sale.Status,
            Date = sale.CreatedAt
        });
    }
}
```

### `src/SalesService/Consumers/StockDeductedConsumer.cs`
```csharp
using MassTransit;
using Microsoft.EntityFrameworkCore;
using FuelManagement.SalesService.Data;
using FuelManagement.Shared.Events;

namespace FuelManagement.SalesService.Consumers;

// ✅ Stock was deducted successfully → CONFIRM the sale
public class StockDeductedConsumer : IConsumer<StockDeductedEvent>
{
    private readonly SalesDbContext _db;
    private readonly IPublishEndpoint _bus;
    private readonly ILogger<StockDeductedConsumer> _logger;

    public StockDeductedConsumer(SalesDbContext db, IPublishEndpoint bus, ILogger<StockDeductedConsumer> logger)
    { _db = db; _bus = bus; _logger = logger; }

    public async Task Consume(ConsumeContext<StockDeductedEvent> context)
    {
        var sale = await _db.FuelSales.FindAsync(context.Message.SaleId);
        if (sale == null) return;

        // ✅ Confirm the sale!
        sale.Status = "Completed";
        await _db.SaveChangesAsync();
        _logger.LogInformation("✅ Sale {Id} COMPLETED!", sale.Id);

        // Notify Admin Service + Notification Service
        await _bus.Publish(new SaleCompletedEvent
        {
            SaleId = sale.Id,
            StationId = sale.StationId,
            FuelType = sale.FuelType,
            Liters = sale.Liters,
            TotalAmount = sale.TotalAmount,
            CompletedAt = DateTime.UtcNow
        });
    }
}
```

### `src/SalesService/Consumers/StockInsufficientConsumer.cs`
```csharp
using MassTransit;
using FuelManagement.SalesService.Data;
using FuelManagement.Shared.Events;

namespace FuelManagement.SalesService.Consumers;

// ❌ Not enough stock → CANCEL the sale (SAGA COMPENSATION!)
public class StockInsufficientConsumer : IConsumer<StockInsufficientEvent>
{
    private readonly SalesDbContext _db;
    private readonly IPublishEndpoint _bus;
    private readonly ILogger<StockInsufficientConsumer> _logger;

    public StockInsufficientConsumer(SalesDbContext db, IPublishEndpoint bus, ILogger<StockInsufficientConsumer> logger)
    { _db = db; _bus = bus; _logger = logger; }

    public async Task Consume(ConsumeContext<StockInsufficientEvent> context)
    {
        var sale = await _db.FuelSales.FindAsync(context.Message.SaleId);
        if (sale == null) return;

        // ❌ Cancel the sale
        sale.Status = "Failed";
        await _db.SaveChangesAsync();
        _logger.LogWarning("❌ Sale {Id} FAILED: {Reason}", sale.Id, context.Message.Reason);

        await _bus.Publish(new SaleCancelledEvent
        {
            SaleId = sale.Id,
            StationId = sale.StationId,
            Reason = context.Message.Reason
        });
    }
}
```

### `src/SalesService/Program.cs`
```csharp
using System.Text;
using MassTransit;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FuelManagement.SalesService.Consumers;
using FuelManagement.SalesService.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<SalesDbContext>(opt =>
    opt.UseNpgsql(builder.Configuration.GetConnectionString("SalesDb")));

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(opt => { opt.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
    }; });
builder.Services.AddAuthorization();

builder.Services.AddMassTransit(x =>
{
    x.AddConsumer<StockDeductedConsumer>();      // Saga: stock OK
    x.AddConsumer<StockInsufficientConsumer>();  // Saga: stock failed
    x.UsingRabbitMq((ctx, cfg) => {
        cfg.Host(builder.Configuration["RabbitMq:Host"] ?? "localhost");
        cfg.ConfigureEndpoints(ctx);
    });
});

builder.Services.AddControllers();
builder.Services.AddSwaggerGen();
var app = builder.Build();
using (var scope = app.Services.CreateScope())
{ scope.ServiceProvider.GetRequiredService<SalesDbContext>().Database.Migrate(); }
app.UseSwagger(); app.UseSwaggerUI();
app.UseAuthentication(); app.UseAuthorization();
app.MapControllers();
app.Run();
```

---

## NOTIFICATION SERVICE

### `src/NotificationService/Consumers/NotificationConsumers.cs`
```csharp
using MassTransit;
using FuelManagement.Shared.Events;

namespace FuelManagement.NotificationService.Consumers;

public class SaleCompletedNotifier : IConsumer<SaleCompletedEvent>
{
    private readonly ILogger<SaleCompletedNotifier> _log;
    public SaleCompletedNotifier(ILogger<SaleCompletedNotifier> log) => _log = log;

    public Task Consume(ConsumeContext<SaleCompletedEvent> ctx)
    {
        _log.LogInformation("📧 Sale {Id}: {Liters}L {FuelType} = ₹{Amount}",
            ctx.Message.SaleId, ctx.Message.Liters, ctx.Message.FuelType, ctx.Message.TotalAmount);
        return Task.CompletedTask;
    }
}

public class LowStockNotifier : IConsumer<LowStockAlertEvent>
{
    private readonly ILogger<LowStockNotifier> _log;
    public LowStockNotifier(ILogger<LowStockNotifier> log) => _log = log;

    public Task Consume(ConsumeContext<LowStockAlertEvent> ctx)
    {
        _log.LogWarning("🚨 LOW STOCK: {Station} — {FuelType} only {Liters}L left!",
            ctx.Message.StationName, ctx.Message.FuelType, ctx.Message.CurrentLiters);
        return Task.CompletedTask;
    }
}

public class SaleCancelledNotifier : IConsumer<SaleCancelledEvent>
{
    private readonly ILogger<SaleCancelledNotifier> _log;
    public SaleCancelledNotifier(ILogger<SaleCancelledNotifier> log) => _log = log;

    public Task Consume(ConsumeContext<SaleCancelledEvent> ctx)
    {
        _log.LogWarning("❌ Sale {Id} cancelled: {Reason}", ctx.Message.SaleId, ctx.Message.Reason);
        return Task.CompletedTask;
    }
}
```

### `src/NotificationService/Program.cs`
```csharp
using MassTransit;
using FuelManagement.NotificationService.Consumers;

var builder = Host.CreateApplicationBuilder(args);
builder.Services.AddMassTransit(x =>
{
    x.AddConsumer<SaleCompletedNotifier>();
    x.AddConsumer<LowStockNotifier>();
    x.AddConsumer<SaleCancelledNotifier>();
    x.UsingRabbitMq((ctx, cfg) => {
        cfg.Host(builder.Configuration["RabbitMq:Host"] ?? "localhost");
        cfg.ConfigureEndpoints(ctx);
    });
});
var host = builder.Build();
host.Run();
```

---

## OCELOT API GATEWAY

### `src/Gateway/ocelot.json`
```json
{
  "Routes": [
    {
      "DownstreamPathTemplate": "/api/auth/{everything}",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "identity-service", "Port": 80 }],
      "UpstreamPathTemplate": "/api/auth/{everything}",
      "UpstreamHttpMethod": ["POST","GET"],
      "RateLimitOptions": { "EnableRateLimiting": true, "Period": "1m", "Limit": 20 }
    },
    {
      "DownstreamPathTemplate": "/api/stations/{everything}",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "fuel-service", "Port": 80 }],
      "UpstreamPathTemplate": "/api/stations/{everything}",
      "UpstreamHttpMethod": ["GET","POST"],
      "AuthenticationOptions": { "AuthenticationProviderKey": "Bearer" },
      "RateLimitOptions": { "EnableRateLimiting": true, "Period": "1m", "Limit": 100 }
    },
    {
      "DownstreamPathTemplate": "/api/stations",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "fuel-service", "Port": 80 }],
      "UpstreamPathTemplate": "/api/stations",
      "UpstreamHttpMethod": ["GET","POST"]
    },
    {
      "DownstreamPathTemplate": "/api/fuel-stock/{everything}",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "fuel-service", "Port": 80 }],
      "UpstreamPathTemplate": "/api/fuel-stock/{everything}",
      "UpstreamHttpMethod": ["GET","PUT"],
      "AuthenticationOptions": { "AuthenticationProviderKey": "Bearer" },
      "RateLimitOptions": { "EnableRateLimiting": true, "Period": "1m", "Limit": 100 }
    },
    {
      "DownstreamPathTemplate": "/api/sales/{everything}",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "sales-service", "Port": 80 }],
      "UpstreamPathTemplate": "/api/sales/{everything}",
      "UpstreamHttpMethod": ["GET","POST"],
      "AuthenticationOptions": { "AuthenticationProviderKey": "Bearer" },
      "RateLimitOptions": { "EnableRateLimiting": true, "Period": "1m", "Limit": 30 }
    },
    {
      "DownstreamPathTemplate": "/api/sales",
      "DownstreamScheme": "http",
      "DownstreamHostAndPorts": [{ "Host": "sales-service", "Port": 80 }],
      "UpstreamPathTemplate": "/api/sales",
      "UpstreamHttpMethod": ["GET","POST"],
      "AuthenticationOptions": { "AuthenticationProviderKey": "Bearer" },
      "RateLimitOptions": { "EnableRateLimiting": true, "Period": "1m", "Limit": 30 }
    }
  ],
  "GlobalConfiguration": {
    "BaseUrl": "http://localhost:5000",
    "RateLimitOptions": {
      "DisableRateLimitHeaders": false,
      "QuotaExceededMessage": "Too many requests! Please wait.",
      "HttpStatusCode": 429
    }
  }
}
```

### `src/Gateway/Program.cs`
```csharp
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration.AddJsonFile("ocelot.json", false, true);

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer("Bearer", opt => {
        opt.RequireHttpsMetadata = false;
        opt.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true, ValidateAudience = true,
            ValidateLifetime = true, ValidateIssuerSigningKey = true,
            ValidIssuer = "FuelManagement",
            ValidAudience = "FuelManagementUsers",
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes("FuelManagementSecretKey12345678!"))
        };
    });

builder.Services.AddOcelot();
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins("http://localhost:3000","http://localhost:5173").AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseCors();
await app.UseOcelot();
app.Run();
```

---

## DOCKER COMPOSE

### `docker-compose.yml`
```yaml
version: '3.8'
services:
  sqlserver:
    image: mcr.microsoft.com/mssql/server:2022-latest
    environment: { SA_PASSWORD: "YourPassword123!", ACCEPT_EULA: "Y" }
    ports: ["1433:1433"]

  postgres-fuel:
    image: postgres:16-alpine
    environment: { POSTGRES_DB: FuelDb, POSTGRES_USER: postgres, POSTGRES_PASSWORD: postgres }
    ports: ["5432:5432"]

  postgres-sales:
    image: postgres:16-alpine
    environment: { POSTGRES_DB: SalesDb, POSTGRES_USER: postgres, POSTGRES_PASSWORD: postgres }
    ports: ["5433:5432"]

  rabbitmq:
    image: rabbitmq:3-management-alpine
    ports: ["5672:5672", "15672:15672"]

  identity-service:
    build: { context: ., dockerfile: src/IdentityService/Dockerfile }
    environment:
      - ConnectionStrings__AuthDb=Server=sqlserver;Database=FuelAuthDb;User=sa;Password=YourPassword123!;TrustServerCertificate=True
      - Jwt__Key=FuelManagementSecretKey12345678!
      - Jwt__Issuer=FuelManagement
      - Jwt__Audience=FuelManagementUsers
    depends_on: [sqlserver]

  fuel-service:
    build: { context: ., dockerfile: src/FuelService/Dockerfile }
    environment:
      - ConnectionStrings__FuelDb=Host=postgres-fuel;Database=FuelDb;Username=postgres;Password=postgres
      - RabbitMq__Host=rabbitmq
      - Jwt__Key=FuelManagementSecretKey12345678!
      - Jwt__Issuer=FuelManagement
      - Jwt__Audience=FuelManagementUsers
    depends_on: [postgres-fuel, rabbitmq]

  sales-service:
    build: { context: ., dockerfile: src/SalesService/Dockerfile }
    environment:
      - ConnectionStrings__SalesDb=Host=postgres-sales;Database=SalesDb;Username=postgres;Password=postgres
      - RabbitMq__Host=rabbitmq
      - Jwt__Key=FuelManagementSecretKey12345678!
      - Jwt__Issuer=FuelManagement
      - Jwt__Audience=FuelManagementUsers
    depends_on: [postgres-sales, rabbitmq]

  notification-service:
    build: { context: ., dockerfile: src/NotificationService/Dockerfile }
    environment: { RabbitMq__Host: rabbitmq }
    depends_on: [rabbitmq]

  api-gateway:
    build: { context: ., dockerfile: src/Gateway/Dockerfile }
    ports: ["5000:80"]
    depends_on: [identity-service, fuel-service, sales-service]

  frontend:
    build: { context: ./frontend/fuel-ui }
    ports: ["3000:80"]
    depends_on: [api-gateway]

  sonarqube:
    image: sonarqube:community
    ports: ["9000:9000"]
    environment: { SONAR_ES_BOOTSTRAP_CHECKS_DISABLE: "true" }
```

---

## CI/CD — `.github/workflows/ci.yml`
```yaml
name: Fuel Management CI/CD
on:
  push: { branches: [main] }
  pull_request: { branches: [main] }

jobs:
  build-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-dotnet@v4
        with: { dotnet-version: '8.0.x' }
      - run: dotnet restore FuelManagement.sln
      - run: dotnet build FuelManagement.sln -c Release --no-restore
      - run: dotnet test FuelManagement.sln -c Release --no-build
      - uses: sonarsource/sonarqube-scan-action@v2
        env:
          SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}
          SONAR_HOST_URL: ${{ secrets.SONAR_HOST_URL }}

  docker-push:
    needs: build-test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    strategy:
      matrix:
        svc: [IdentityService, FuelService, SalesService, NotificationService, Gateway]
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with: { username: "${{ secrets.DOCKER_USERNAME }}", password: "${{ secrets.DOCKER_PASSWORD }}" }
      - uses: docker/build-push-action@v5
        with:
          context: .
          file: src/${{ matrix.svc }}/Dockerfile
          push: true
          tags: ${{ secrets.DOCKER_USERNAME }}/fuel-${{ matrix.svc }}:latest
```

### `sonar-project.properties`
```properties
sonar.projectKey=fuel-management
sonar.projectName=FuelManagement
sonar.sources=src/
sonar.tests=tests/
sonar.exclusions=**/Migrations/**,**/obj/**,**/bin/**
```
