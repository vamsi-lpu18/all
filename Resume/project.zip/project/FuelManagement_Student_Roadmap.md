# ⛽ Indian Fuel Management System — Student Roadmap

> Build this project in **6 sprints (6 weeks)**. Each sprint = 1 week.

---

## 🗓️ Sprint 1: Foundation (Week 1)

### Goals: Setup + Identity Service + Auth working

**Day 1-2: Project Setup**
```powershell
# Create everything
mkdir FuelManagementSystem
cd FuelManagementSystem
dotnet new sln -n FuelManagement

# Shared library
dotnet new classlib -n FuelManagement.Shared -o src/Shared/FuelManagement.Shared

# Microservices
dotnet new webapi -n FuelManagement.IdentityService -o src/IdentityService
dotnet new webapi -n FuelManagement.FuelService -o src/FuelService
dotnet new webapi -n FuelManagement.SalesService -o src/SalesService
dotnet new webapi -n FuelManagement.AdminService -o src/AdminService
dotnet new worker -n FuelManagement.NotificationService -o src/NotificationService

# Gateway
dotnet new webapi -n FuelManagement.Gateway -o src/Gateway --no-openapi

# Tests
dotnet new xunit -n FuelManagement.Tests -o tests/FuelManagement.Tests

# Add all to solution
dotnet sln add src/Shared/FuelManagement.Shared
dotnet sln add src/IdentityService
dotnet sln add src/FuelService
dotnet sln add src/SalesService
dotnet sln add src/AdminService
dotnet sln add src/NotificationService
dotnet sln add src/Gateway
dotnet sln add tests/FuelManagement.Tests
```

**Day 2-3: Install Packages**
```powershell
# Shared
cd src/Shared/FuelManagement.Shared
dotnet add package MassTransit --version 8.2.5
cd ../..

# Identity Service
cd IdentityService
dotnet add package Microsoft.AspNetCore.Identity.EntityFrameworkCore
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package Swashbuckle.AspNetCore
dotnet add reference ../Shared/FuelManagement.Shared/FuelManagement.Shared.csproj
cd ..

# Fuel Service
cd FuelService
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package MassTransit.RabbitMQ --version 8.2.5
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
dotnet add package Swashbuckle.AspNetCore
dotnet add reference ../Shared/FuelManagement.Shared/FuelManagement.Shared.csproj
cd ..

# Sales Service
cd SalesService
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package MassTransit.RabbitMQ --version 8.2.5
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
dotnet add package Swashbuckle.AspNetCore
dotnet add reference ../Shared/FuelManagement.Shared/FuelManagement.Shared.csproj
cd ..

# Admin Service
cd AdminService
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet add package MassTransit.RabbitMQ --version 8.2.5
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
dotnet add package Swashbuckle.AspNetCore
dotnet add reference ../Shared/FuelManagement.Shared/FuelManagement.Shared.csproj
cd ..

# Notification Service
cd NotificationService
dotnet add package MassTransit.RabbitMQ --version 8.2.5
dotnet add reference ../Shared/FuelManagement.Shared/FuelManagement.Shared.csproj
cd ..

# Gateway
cd Gateway
dotnet add package Ocelot --version 23.4.2
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
cd ../..
```

**Day 3-5: Build Identity Service**
- Create `AppUser` model (extends IdentityUser)
- Create `AuthDbContext` with role seeding (Admin, Dealer, Customer)
- Create `AuthController` — register, login, get profile
- Generate JWT tokens with role claims
- Test with Swagger: register → login → get token → use token

**Day 5-7: Build Shared Library**
- Create all event classes (SaleCreatedEvent, StockDeductedEvent, etc.)
- Create all DTO classes
- Build & verify solution compiles

**✅ Sprint 1 Deliverable:** Identity Service working, can register/login via Swagger

---

## 🗓️ Sprint 2: Fuel Inventory Service (Week 2)

### Goals: Stations + Fuel Stock + Refill working

**Day 1-3: Models + Database**
- Create `Station` model (name, address, city, dealerId)
- Create `FuelStock` model (stationId, fuelType, currentLiters, pricePerLiter)
- Create `FuelRefill` model (stationId, litersAdded, supplierName)
- Create `FuelDbContext` with Code-First configuration
- Seed sample stations and stock data
- Run migration: `dotnet ef migrations add Init` → `dotnet ef database update`

**Day 3-5: Controllers**
- `StationsController` — GET all, GET by id, POST create (Admin only)
- `FuelStockController` — GET stock by station, PUT refill (Dealer only)
- Add `[Authorize]` with role checks

**Day 5-7: RabbitMQ Consumer**
- Create `SaleCreatedConsumer` — listens for sale events
- Checks if stock is enough → deducts stock → publishes result
- If not enough → publishes `StockInsufficientEvent` (Saga compensation)

**✅ Sprint 2 Deliverable:** Fuel Service running, can CRUD stations & stock via Swagger

---

## 🗓️ Sprint 3: Sales Service + Saga Pattern (Week 3)

### Goals: Record fuel sales + Saga workflow working

**Day 1-3: Models + Database**
- Create `FuelSale` model (stationId, fuelType, liters, totalAmount, status)
- Create `SalesDbContext`
- Run migration

**Day 3-5: Controller + Saga**
- `SalesController` — POST create sale (triggers saga), GET sales
- On POST: create sale with "Pending" status → publish `SaleCreatedEvent`
- Create `StockDeductedConsumer` — confirm sale ✅
- Create `StockInsufficientConsumer` — cancel sale ❌ (compensation)

**Day 5-7: Test the Saga**
- Start Fuel Service + Sales Service + RabbitMQ
- Create a sale → see it go Pending → then Confirmed or Failed
- Test with insufficient stock → see compensation happen

**✅ Sprint 3 Deliverable:** Full Saga working — sale → stock check → confirm/cancel

---

## 🗓️ Sprint 4: Admin Service + Gateway + Notification (Week 4)

### Goals: Reports, Gateway routing, Notifications

**Day 1-2: Admin/Reporting Service**
- Create `DailyReport` model + `FraudAlert` model
- Create `AdminDbContext`
- `ReportsController` — generate daily report, revenue report
- `FraudAlertsController` — view fraud alerts
- Create `SaleCompletedConsumer` — updates daily totals

**Day 3-4: Notification Service**
- Create consumers for: SaleCompleted, LowStockAlert, FraudDetected
- Log notifications (simulated email)

**Day 4-6: Ocelot API Gateway**
- Create `ocelot.json` with all routes
- Add rate limiting per route
- Add JWT authentication at gateway level
- Test: all API calls go through `localhost:5000`

**Day 6-7: Integration Testing**
- Start ALL services
- Test full flow: login → create sale → saga runs → report updates
- Verify rate limiting works (spam requests → 429 error)

**✅ Sprint 4 Deliverable:** All 4 services + gateway + notification working together

---

## 🗓️ Sprint 5: React Frontend (Week 5)

### Goals: Full working UI

**Day 1: Setup**
```bash
cd frontend
npx -y create-vite@latest fuel-ui -- --template react-ts
cd fuel-ui
npm install axios react-router-dom recharts
```

**Day 1-2: Auth + Layout**
- Create `api.ts` (axios with JWT interceptor)
- Create `AuthContext.tsx` (login/logout state)
- Create `Login.tsx` page
- Create `Layout.tsx` with sidebar navigation

**Day 2-3: Customer Pages**
- Fuel prices page (GET stations with prices)
- My transactions page (GET my sales)

**Day 3-5: Dealer Pages**
- Dealer dashboard (station overview, stock levels)
- Record sale form (POST sale, triggers saga)
- Refill stock form (PUT refill)
- View station sales

**Day 5-7: Admin Pages**
- Admin dashboard (all stations overview)
- Revenue charts (using recharts)
- Daily reports page
- Fraud alerts page
- User management

**✅ Sprint 5 Deliverable:** Full React frontend connected to gateway

---

## 🗓️ Sprint 6: Docker, CI/CD, SonarQube, Testing (Week 6)

### Goals: Deployment ready

**Day 1-2: Docker**
- Create Dockerfile for each service
- Create `docker-compose.yml` with all services + databases + RabbitMQ
- Test: `docker-compose up --build -d`

**Day 2-3: Scaling**
- Add replicas for Fuel Service (high traffic)
- Configure Ocelot round-robin load balancing

**Day 3-4: CI/CD**
- Create `.github/workflows/ci.yml`
- Pipeline: Restore → Build → Test → SonarQube Scan → Docker Build → Push

**Day 4-5: SonarQube**
- Create `sonar-project.properties`
- Run SonarQube locally via Docker
- Fix any code smells or bugs

**Day 5-6: Testing**
- Write unit tests for controllers (xUnit + Moq)
- Write integration tests
- Achieve >80% coverage

**Day 6-7: Documentation**
- Create UML diagrams (Use Case, Sequence, Class, ER)
- Write README.md
- Final testing of complete system

**✅ Sprint 6 Deliverable:** Full project deployed with Docker, CI/CD, SonarQube, tests

---

## 📁 Final Folder Structure

```
FuelManagementSystem/
├── FuelManagement.sln
├── docker-compose.yml
├── sonar-project.properties
├── .github/workflows/ci.yml
│
├── src/
│   ├── Shared/FuelManagement.Shared/
│   │   ├── Events/           # RabbitMQ events
│   │   └── DTOs/             # Data transfer objects
│   │
│   ├── IdentityService/      # Auth + JWT
│   │   ├── Models/AppUser.cs
│   │   ├── Data/AuthDbContext.cs
│   │   ├── Controllers/AuthController.cs
│   │   ├── Program.cs
│   │   └── Dockerfile
│   │
│   ├── FuelService/           # Inventory + Stock
│   │   ├── Models/Station.cs, FuelStock.cs, FuelRefill.cs
│   │   ├── Data/FuelDbContext.cs
│   │   ├── Controllers/StationsController.cs, FuelStockController.cs
│   │   ├── Consumers/SaleCreatedConsumer.cs    ← SAGA
│   │   ├── Program.cs
│   │   └── Dockerfile
│   │
│   ├── SalesService/          # Sales + Saga
│   │   ├── Models/FuelSale.cs
│   │   ├── Data/SalesDbContext.cs
│   │   ├── Controllers/SalesController.cs
│   │   ├── Consumers/StockDeductedConsumer.cs   ← SAGA ✅
│   │   ├── Consumers/StockInsufficientConsumer.cs ← COMPENSATION ❌
│   │   ├── Program.cs
│   │   └── Dockerfile
│   │
│   ├── AdminService/          # Reports + Fraud
│   │   ├── Models/DailyReport.cs, FraudAlert.cs
│   │   ├── Data/AdminDbContext.cs
│   │   ├── Controllers/ReportsController.cs, FraudAlertsController.cs
│   │   ├── Consumers/SaleCompletedConsumer.cs
│   │   ├── Program.cs
│   │   └── Dockerfile
│   │
│   ├── NotificationService/   # Background Worker
│   │   ├── Consumers/         # Alert consumers
│   │   ├── Program.cs
│   │   └── Dockerfile
│   │
│   └── Gateway/               # Ocelot API Gateway
│       ├── ocelot.json        ← Routes + Rate Limiting
│       ├── Program.cs
│       └── Dockerfile
│
├── frontend/fuel-ui/          # React App
│   ├── src/
│   │   ├── services/api.ts
│   │   ├── context/AuthContext.tsx
│   │   ├── pages/Login.tsx, CustomerDashboard.tsx, DealerDashboard.tsx, AdminDashboard.tsx, etc.
│   │   ├── App.tsx
│   │   └── App.css
│   └── Dockerfile
│
└── tests/FuelManagement.Tests/
```

---

## 🔧 Tools You Need (Install These First)

| Tool | Download | Why |
|------|----------|-----|
| **.NET 8 SDK** | https://dotnet.microsoft.com/download | Backend services |
| **Node.js 20** | https://nodejs.org | React frontend |
| **Docker Desktop** | https://docker.com/get-started | Run databases + services |
| **VS Code** | https://code.visualstudio.com | Code editor |
| **Git** | https://git-scm.com | Version control |
| **Postman** | https://postman.com | Test APIs |

### VS Code Extensions
- C# Dev Kit
- Docker
- ESLint
- Thunder Client (API testing)

---

## 💡 Tips for Students

1. **Build one service at a time** — don't try to build everything at once
2. **Test each service with Swagger** before connecting them
3. **Run RabbitMQ in Docker first**: `docker run -d -p 5672:5672 -p 15672:15672 rabbitmq:3-management`
4. **Run PostgreSQL in Docker**: `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres postgres:16`
5. **Run SQL Server in Docker**: `docker run -d -p 1433:1433 -e ACCEPT_EULA=Y -e SA_PASSWORD=YourPassword123! mcr.microsoft.com/mssql/server:2022-latest`
6. **Check RabbitMQ dashboard** at `http://localhost:15672` (guest/guest) to see queues
7. **Use the same JWT key** in all services' `appsettings.json`
8. **Git commit after each sprint** — one commit per working feature
