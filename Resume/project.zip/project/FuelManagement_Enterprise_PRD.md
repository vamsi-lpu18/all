# ⛽ Indian Fuel Management System — Enterprise PRD

## A) Application Overview

The **Indian Fuel Management System (IFMS)** is an enterprise-grade, cloud-native microservices platform for managing fuel distribution, inventory, sales, and compliance monitoring across Indian petrol bunks and fuel stations.

It enables **real-time tracking** of fuel stock levels, sales transactions, dealer operations, and regulatory compliance — addressing issues like fuel theft, stock mismatch, and tax reporting.

---

## B) Enterprise Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Frontend** | React 18 + Vite + TypeScript | User Interface |
| **API Gateway** | Ocelot API Gateway | Routing, Rate Limiting, Auth |
| **Microservices** | ASP.NET Core 8 Web API | Backend services |
| **ORM** | Entity Framework Core (Code-First) | Database access |
| **Database** | SQL Server (Auth), PostgreSQL (others) | DB per microservice |
| **Messaging** | RabbitMQ + MassTransit | Async events, Saga pattern |
| **Saga Pattern** | MassTransit State Machine | Fuel order workflow |
| **Auth** | JWT + ASP.NET Identity | Authentication + Authorization |
| **Rate Limiting** | Ocelot RateLimitOptions | API throttling |
| **Containerization** | Docker + Docker Compose | Deployment |
| **CI/CD** | GitHub Actions | Build, Test, Deploy pipeline |
| **Code Quality** | SonarQube | Static analysis |
| **Scaling** | Docker Compose replicas + Ocelot Load Balancer | Horizontal scaling |

---

## C) Objective

1. **Centralized fuel inventory management** across multiple stations
2. **Real-time sales tracking** with receipt generation
3. **Secure architecture** with JWT auth + role-based access
4. **Saga pattern** for fuel order lifecycle (Order → Pay → Dispense → or Compensate)
5. **Async communication** between services via RabbitMQ
6. **Fraud detection** — flag mismatches between stock and sales
7. **Regulatory compliance** — GST reports, daily stock registers
8. **Scalable** — handle multiple stations simultaneously

---

## D) Roles & Access Control

| Role | Access | What They Can Do |
|------|--------|-----------------|
| **Customer** | `/customer/*` | View fuel prices, transaction history, receipts |
| **Dealer** | `/dealer/*` | Manage station, update stock, record sales, view reports |
| **Admin** | `/admin/*` | Monitor all stations, generate reports, manage users, fraud alerts |

### Security Implementation
- **JWT Tokens** — issued by Identity Service, validated at Gateway
- **Role-based `[Authorize]`** — on every controller endpoint
- **React Route Guards** — `ProtectedRoute` component checks login + role
- **Rate Limiting** — Ocelot blocks excessive requests (anti-abuse)

---

## E) Microservices Architecture

```
┌──────────────┐
│  React App   │
│  (Frontend)  │
└──────┬───────┘
       │ HTTP
┌──────▼───────────────────────────────┐
│       Ocelot API Gateway             │
│  Rate Limiting | JWT Auth | Routing  │
└──┬───────┬──────────┬───────────┬────┘
   │       │          │           │
┌──▼──┐ ┌──▼──┐  ┌────▼───┐  ┌───▼────┐
│Auth │ │Fuel │  │ Sales  │  │ Admin  │
│Svc  │ │Svc  │  │  Svc   │  │  Svc   │
└──┬──┘ └──┬──┘  └────┬───┘  └───┬────┘
   │       │          │           │
┌──▼──┐ ┌──▼──┐  ┌────▼───┐  ┌───▼────┐
│Auth │ │Fuel │  │ Sales  │  │ Admin  │
│ DB  │ │ DB  │  │  DB    │  │  DB    │
└─────┘ └─────┘  └────────┘  └────────┘
              ↕          ↕
         ┌────────────────────┐
         │     RabbitMQ       │
         │   (Event Bus)      │
         └────────┬───────────┘
                  │
         ┌────────▼───────────┐
         │ Notification Svc   │
         │ (Background Worker) │
         └────────────────────┘
```

### 4 Microservices + 1 Worker

| # | Service | Port | Database | Responsibility |
|---|---------|------|----------|----------------|
| 1 | **Identity Service** | 5001 | AuthDB (SQL Server) | Register, Login, JWT, Roles |
| 2 | **Fuel Inventory Service** | 5002 | FuelDB (PostgreSQL) | Stations, Fuel Stock, Tank Levels |
| 3 | **Sales Service** | 5003 | SalesDB (PostgreSQL) | Fuel Sales, Receipts, Saga |
| 4 | **Admin/Reporting Service** | 5004 | AdminDB (PostgreSQL) | Reports, Fraud Detection, Analytics |
| 5 | **Notification Service** | — | None (stateless) | RabbitMQ worker, sends alerts |
| GW | **Ocelot API Gateway** | 5000 | None | Routes all traffic |

---

## F) Saga Pattern — Fuel Sale Lifecycle

```
Customer requests fuel purchase
        ↓
1. Sales Service creates sale (status: "Pending")
        ↓
2. Publishes "SaleCreatedEvent" → RabbitMQ
        ↓
3. Fuel Service receives event
   → Checks if enough stock exists
   → If YES: deducts stock → publishes "StockDeductedEvent"
   → If NO: publishes "StockInsufficientEvent"
        ↓
4a. Sales Service hears "StockDeducted" → sale = "Completed" ✅
4b. Sales Service hears "StockInsufficient" → sale = "Failed" ❌ (COMPENSATION)
        ↓
5. Notification Service sends alert to dealer
```

### Status Lifecycle
```
Fuel Loaded → Available → Reserved (sale pending) → Sold → Replenished
                              ↓ (if payment/stock fails)
                          Released back (Compensation)
```

---

## G) Database Design (EF Code-First)

### Identity Service — AuthDB
```
Users
├── Id (GUID)
├── FullName
├── Email
├── PasswordHash (auto by Identity)
├── PhoneNumber
├── Role (Admin/Dealer/Customer)
├── StationId (nullable — for dealers)
└── CreatedAt
```

### Fuel Inventory Service — FuelDB
```
Stations                          FuelStock
├── Id (GUID)                     ├── Id (GUID)
├── Name ("HP Pump Koramangala")  ├── StationId (FK)
├── Address                       ├── FuelType (Petrol/Diesel/CNG)
├── City                          ├── CurrentLiters
├── State                         ├── TankCapacity
├── LicenseNumber                 ├── PricePerLiter
├── DealerId (FK to User)         ├── LastRefillDate
├── IsActive                      └── UpdatedAt
└── CreatedAt

FuelRefills
├── Id
├── StationId
├── FuelType
├── LitersAdded
├── SupplierName
├── InvoiceNumber
└── RefilledAt
```

### Sales Service — SalesDB
```
FuelSales
├── Id (GUID)
├── StationId
├── CustomerId (nullable)
├── FuelType (Petrol/Diesel)
├── Liters
├── PricePerLiter
├── TotalAmount
├── PaymentMethod (Cash/UPI/Card)
├── VehicleNumber
├── Status (Pending/Completed/Failed)
├── ReceiptNumber
└── CreatedAt
```

### Admin Service — AdminDB
```
DailyReports
├── Id
├── StationId
├── Date
├── TotalPetrolSold
├── TotalDieselSold
├── TotalRevenue
├── OpeningStock
├── ClosingStock
└── GeneratedAt

FraudAlerts
├── Id
├── StationId
├── AlertType (StockMismatch/UnusualSale)
├── Description
├── Severity (Low/Medium/High)
├── IsResolved
└── DetectedAt
```

---

## H) REST API Summary

### Through Ocelot Gateway (http://localhost:5000)

**Auth APIs:**
| Method | URL | Access | Action |
|--------|-----|--------|--------|
| POST | `/api/auth/register` | Public | Register user |
| POST | `/api/auth/login` | Public | Login, get JWT |
| GET | `/api/auth/me` | Auth | Get profile |

**Fuel Inventory APIs:**
| Method | URL | Access | Action |
|--------|-----|--------|--------|
| GET | `/api/stations` | Auth | List all stations |
| GET | `/api/stations/{id}` | Auth | Station details |
| POST | `/api/stations` | Admin | Create station |
| GET | `/api/fuel-stock/{stationId}` | Auth | Get stock levels |
| PUT | `/api/fuel-stock/{id}/refill` | Dealer | Add fuel refill |

**Sales APIs:**
| Method | URL | Access | Action |
|--------|-----|--------|--------|
| POST | `/api/sales` | Dealer | Record fuel sale (triggers Saga) |
| GET | `/api/sales` | Auth | Get my sales/station sales |
| GET | `/api/sales/{id}/receipt` | Auth | Get receipt |

**Admin APIs:**
| Method | URL | Access | Action |
|--------|-----|--------|--------|
| GET | `/api/reports/daily?stationId=&date=` | Admin | Daily report |
| GET | `/api/reports/revenue?from=&to=` | Admin | Revenue report |
| GET | `/api/fraud-alerts` | Admin | Fraud alerts |

---

## I) RabbitMQ Events

| Event | Publisher | Consumer | What Happens |
|-------|----------|----------|-------------|
| `SaleCreatedEvent` | Sales Service | Fuel Service | Check & deduct stock |
| `StockDeductedEvent` | Fuel Service | Sales Service | Confirm the sale ✅ |
| `StockInsufficientEvent` | Fuel Service | Sales Service | Cancel the sale ❌ |
| `SaleCompletedEvent` | Sales Service | Admin Service | Update daily report |
| `SaleCompletedEvent` | Sales Service | Notification Svc | Alert dealer |
| `LowStockAlertEvent` | Fuel Service | Notification Svc | Alert admin |
| `FraudDetectedEvent` | Admin Service | Notification Svc | Alert admin |

---

## J) React Frontend Pages

| Page | Route | Role | Features |
|------|-------|------|----------|
| Login/Register | `/login` | Public | JWT auth |
| **Customer Dashboard** | `/customer` | Customer | Fuel prices, my transactions |
| **Dealer Dashboard** | `/dealer` | Dealer | Station overview, stock, sales |
| **Record Sale** | `/dealer/sell` | Dealer | Enter sale, triggers Saga |
| **Refill Stock** | `/dealer/refill` | Dealer | Add fuel delivery |
| **Admin Dashboard** | `/admin` | Admin | All stations, revenue charts |
| **Reports** | `/admin/reports` | Admin | Daily/weekly/monthly reports |
| **Fraud Alerts** | `/admin/alerts` | Admin | Stock mismatch warnings |

---

## K) Rate Limiting (Ocelot Gateway)

| Route | Limit | Why |
|-------|-------|-----|
| `/api/auth/*` | 20/min | Prevent brute force login |
| `/api/fuel-stock/*` | 100/min | Frequent stock checks OK |
| `/api/sales` POST | 30/min | Prevent duplicate sales |
| `/api/reports/*` | 10/min | Heavy queries, limit load |

---

## L) Docker Services

```yaml
# docker-compose.yml will contain:
- sqlserver         # Auth database
- postgres-fuel     # Fuel inventory database
- postgres-sales    # Sales database
- postgres-admin    # Admin/reports database
- rabbitmq          # Message bus + management UI
- identity-service  # Auth microservice
- fuel-service      # Inventory microservice
- sales-service     # Sales microservice
- admin-service     # Reporting microservice
- notification-svc  # Background worker
- api-gateway       # Ocelot (port 5000)
- frontend          # React app (port 3000)
- sonarqube         # Code quality (port 9000)
```

---

## M) CI/CD Pipeline (GitHub Actions)

```
Push to GitHub → Build .NET → Run Tests → SonarQube Scan → Build Docker Images → Push to Docker Hub
```

---

## N) Testing

| Type | Tool | Coverage |
|------|------|----------|
| Unit Tests | xUnit + Moq | Controllers, Services |
| Integration Tests | WebApplicationFactory | API endpoints |
| Frontend Tests | Jest + React Testing Library | Components |
| Code Quality | SonarQube | Bugs, Code Smells, Coverage |

---

## O) Student Deliverables

1. ✅ Use Case Diagram
2. ✅ Sequence Diagram (Saga flow)
3. ✅ Class Diagram (EF models)
4. ✅ ER Diagram (database)
5. ✅ Sprint Plan (roadmap below)
6. ✅ Working source code
7. ✅ Docker deployment
8. ✅ Test cases
9. ✅ SonarQube report
