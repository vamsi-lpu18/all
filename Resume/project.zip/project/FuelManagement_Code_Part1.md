# ⛽ Fuel Management System — Complete Code (Part 1)
# Shared Library + Identity Service + Fuel Service

> Every line has comments for students!

---

## SHARED LIBRARY — Events (RabbitMQ Messages)

### `src/Shared/FuelManagement.Shared/Events/SaleCreatedEvent.cs`
```csharp
namespace FuelManagement.Shared.Events;

// When dealer records a new fuel sale
// Sales Service SENDS this → Fuel Service RECEIVES this
public class SaleCreatedEvent
{
    public Guid SaleId { get; set; }          // Which sale
    public Guid StationId { get; set; }       // Which petrol bunk
    public string FuelType { get; set; } = "";  // Petrol or Diesel
    public double Liters { get; set; }        // How many liters
    public decimal TotalAmount { get; set; }  // Total cost
    public DateTime CreatedAt { get; set; }
}
```

### `src/Shared/FuelManagement.Shared/Events/StockDeductedEvent.cs`
```csharp
namespace FuelManagement.Shared.Events;

// Fuel Service says: "Stock deducted successfully!"
// Sales Service hears this → marks sale as Completed ✅
public class StockDeductedEvent
{
    public Guid SaleId { get; set; }
    public Guid StationId { get; set; }
    public string FuelType { get; set; } = "";
    public double LitersDeducted { get; set; }
    public double RemainingStock { get; set; }
}
```

### `src/Shared/FuelManagement.Shared/Events/StockInsufficientEvent.cs`
```csharp
namespace FuelManagement.Shared.Events;

// Fuel Service says: "Not enough fuel in tank!"
// Sales Service hears this → cancels the sale ❌ (SAGA COMPENSATION)
public class StockInsufficientEvent
{
    public Guid SaleId { get; set; }
    public Guid StationId { get; set; }
    public string FuelType { get; set; } = "";
    public double RequestedLiters { get; set; }
    public double AvailableLiters { get; set; }
    public string Reason { get; set; } = "";
}
```

### `src/Shared/FuelManagement.Shared/Events/SaleCompletedEvent.cs`
```csharp
namespace FuelManagement.Shared.Events;

// Sale confirmed → Admin Service updates reports
// Notification Service sends alert to dealer
public class SaleCompletedEvent
{
    public Guid SaleId { get; set; }
    public Guid StationId { get; set; }
    public string FuelType { get; set; } = "";
    public double Liters { get; set; }
    public decimal TotalAmount { get; set; }
    public DateTime CompletedAt { get; set; }
}
```

### `src/Shared/FuelManagement.Shared/Events/LowStockAlertEvent.cs`
```csharp
namespace FuelManagement.Shared.Events;

// When fuel level drops below 500 liters
// Notification Service alerts the admin
public class LowStockAlertEvent
{
    public Guid StationId { get; set; }
    public string StationName { get; set; } = "";
    public string FuelType { get; set; } = "";
    public double CurrentLiters { get; set; }
    public DateTime DetectedAt { get; set; }
}
```

### `src/Shared/FuelManagement.Shared/Events/SaleCancelledEvent.cs`
```csharp
namespace FuelManagement.Shared.Events;

// When sale fails (saga compensation)
public class SaleCancelledEvent
{
    public Guid SaleId { get; set; }
    public Guid StationId { get; set; }
    public string Reason { get; set; } = "";
}
```

## SHARED LIBRARY — DTOs

### `src/Shared/FuelManagement.Shared/DTOs/AuthDtos.cs`
```csharp
namespace FuelManagement.Shared.DTOs;

public class RegisterDto
{
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string PhoneNumber { get; set; } = "";
    public string Role { get; set; } = "Customer";  // Customer, Dealer, Admin
    public Guid? StationId { get; set; }  // Only for dealers
}

public class LoginDto
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}

public class AuthResponseDto
{
    public string Token { get; set; } = "";
    public string UserId { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
}
```

### `src/Shared/FuelManagement.Shared/DTOs/FuelDtos.cs`
```csharp
namespace FuelManagement.Shared.DTOs;

public class CreateStationDto
{
    public string Name { get; set; } = "";          // "HP Petrol Pump"
    public string Address { get; set; } = "";       // "MG Road"
    public string City { get; set; } = "";          // "Bangalore"
    public string State { get; set; } = "";         // "Karnataka"
    public string LicenseNumber { get; set; } = ""; // Government license
}

public class RefillStockDto
{
    public string FuelType { get; set; } = "";      // Petrol or Diesel
    public double LitersAdded { get; set; }         // How many liters delivered
    public string SupplierName { get; set; } = "";  // IOCL, BPCL, HPCL
    public string InvoiceNumber { get; set; } = ""; // Supplier invoice
}

public class RecordSaleDto
{
    public string FuelType { get; set; } = "";       // Petrol or Diesel
    public double Liters { get; set; }               // How many liters
    public string PaymentMethod { get; set; } = "Cash"; // Cash, UPI, Card
    public string VehicleNumber { get; set; } = "";  // KA-01-AB-1234
}
```

---

## IDENTITY SERVICE (Login + Register + JWT)

### `src/IdentityService/Models/AppUser.cs`
```csharp
using Microsoft.AspNetCore.Identity;

namespace FuelManagement.IdentityService.Models;

// Our user — extends IdentityUser which has Email, PasswordHash, etc.
public class AppUser : IdentityUser
{
    public string FullName { get; set; } = "";
    public Guid? StationId { get; set; }  // Which station (for dealers)
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
```

### `src/IdentityService/Data/AuthDbContext.cs`
```csharp
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using FuelManagement.IdentityService.Models;

namespace FuelManagement.IdentityService.Data;

// EF Code-First: this creates the database tables automatically
public class AuthDbContext : IdentityDbContext<AppUser>
{
    public AuthDbContext(DbContextOptions<AuthDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // Create 3 roles when database is first created
        builder.Entity<IdentityRole>().HasData(
            new IdentityRole { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
            new IdentityRole { Id = "2", Name = "Dealer", NormalizedName = "DEALER" },
            new IdentityRole { Id = "3", Name = "Customer", NormalizedName = "CUSTOMER" }
        );
    }
}
```

### `src/IdentityService/Controllers/AuthController.cs`
```csharp
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using FuelManagement.IdentityService.Models;
using FuelManagement.Shared.DTOs;

namespace FuelManagement.IdentityService.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly UserManager<AppUser> _userManager;
    private readonly IConfiguration _config;

    public AuthController(UserManager<AppUser> userManager, IConfiguration config)
    {
        _userManager = userManager;
        _config = config;
    }

    // POST /api/auth/register — Create new account
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterDto dto)
    {
        // Check if email already used
        if (await _userManager.FindByEmailAsync(dto.Email) != null)
            return BadRequest(new { message = "Email already registered!" });

        // Create user
        var user = new AppUser
        {
            UserName = dto.Email,
            Email = dto.Email,
            FullName = dto.FullName,
            PhoneNumber = dto.PhoneNumber,
            StationId = dto.StationId
        };

        var result = await _userManager.CreateAsync(user, dto.Password);
        if (!result.Succeeded)
            return BadRequest(new { errors = result.Errors.Select(e => e.Description) });

        // Assign role (default = Customer)
        var role = new[] { "Admin", "Dealer", "Customer" }.Contains(dto.Role)
            ? dto.Role : "Customer";
        await _userManager.AddToRoleAsync(user, role);

        // Return JWT token
        var token = GenerateToken(user, role);
        return Ok(new AuthResponseDto
        {
            Token = token,
            UserId = user.Id,
            FullName = user.FullName,
            Email = user.Email!,
            Role = role
        });
    }

    // POST /api/auth/login — Login and get JWT token
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto dto)
    {
        var user = await _userManager.FindByEmailAsync(dto.Email);
        if (user == null)
            return Unauthorized(new { message = "Invalid email or password" });

        if (!await _userManager.CheckPasswordAsync(user, dto.Password))
            return Unauthorized(new { message = "Invalid email or password" });

        var roles = await _userManager.GetRolesAsync(user);
        var role = roles.FirstOrDefault() ?? "Customer";
        var token = GenerateToken(user, role);

        return Ok(new AuthResponseDto
        {
            Token = token,
            UserId = user.Id,
            FullName = user.FullName,
            Email = user.Email!,
            Role = role
        });
    }

    // GET /api/auth/me — Get my profile (must be logged in)
    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> GetProfile()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = await _userManager.FindByIdAsync(userId!);
        if (user == null) return NotFound();

        var roles = await _userManager.GetRolesAsync(user);
        return Ok(new { user.Id, user.FullName, user.Email, user.PhoneNumber,
            Role = roles.FirstOrDefault(), user.StationId });
    }

    // Helper: Create JWT token
    private string GenerateToken(AppUser user, string role)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id),
            new(ClaimTypes.Email, user.Email!),
            new(ClaimTypes.Name, user.FullName),
            new(ClaimTypes.Role, role)
        };

        if (user.StationId.HasValue)
            claims.Add(new Claim("StationId", user.StationId.Value.ToString()));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _config["Jwt:Issuer"],
            audience: _config["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
```

### `src/IdentityService/Program.cs`
```csharp
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FuelManagement.IdentityService.Data;
using FuelManagement.IdentityService.Models;

var builder = WebApplication.CreateBuilder(args);

// 1. Connect to SQL Server database
builder.Services.AddDbContext<AuthDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("AuthDb")));

// 2. Setup ASP.NET Identity (handles users, passwords, roles)
builder.Services.AddIdentity<AppUser, IdentityRole>(opt =>
{
    opt.Password.RequiredLength = 6;
    opt.Password.RequireUppercase = false;
    opt.Password.RequireNonAlphanumeric = false;
})
.AddEntityFrameworkStores<AuthDbContext>()
.AddDefaultTokenProviders();

// 3. Setup JWT authentication
builder.Services.AddAuthentication(opt =>
{
    opt.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    opt.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(opt =>
{
    opt.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
    };
});

builder.Services.AddAuthorization();
builder.Services.AddControllers();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Auto-create database tables
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AuthDbContext>();
    db.Database.Migrate();
}

app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
```

### `src/IdentityService/appsettings.json`
```json
{
  "ConnectionStrings": {
    "AuthDb": "Server=localhost,1433;Database=FuelAuthDb;User=sa;Password=YourPassword123!;TrustServerCertificate=True"
  },
  "Jwt": {
    "Key": "FuelManagementSecretKey12345678!",
    "Issuer": "FuelManagement",
    "Audience": "FuelManagementUsers"
  }
}
```

---

## FUEL INVENTORY SERVICE

### `src/FuelService/Models/Station.cs`
```csharp
namespace FuelManagement.FuelService.Models;

// A petrol bunk / fuel station
public class Station
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";          // "HP Petrol Pump"
    public string Address { get; set; } = "";
    public string City { get; set; } = "";
    public string State { get; set; } = "";
    public string LicenseNumber { get; set; } = ""; // Government license
    public Guid? DealerId { get; set; }              // Which dealer runs it
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
```

### `src/FuelService/Models/FuelStock.cs`
```csharp
namespace FuelManagement.FuelService.Models;

// How much fuel is in each station's tank
public class FuelStock
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StationId { get; set; }              // Which station
    public string FuelType { get; set; } = "";       // "Petrol" or "Diesel"
    public double CurrentLiters { get; set; }        // How much fuel right now
    public double TankCapacity { get; set; }         // Max tank size
    public decimal PricePerLiter { get; set; }       // Current price
    public DateTime LastRefillDate { get; set; }
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    // Navigation: link to Station table
    public Station? Station { get; set; }
}
```

### `src/FuelService/Models/FuelRefill.cs`
```csharp
namespace FuelManagement.FuelService.Models;

// Record of fuel delivery to station
public class FuelRefill
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid StationId { get; set; }
    public string FuelType { get; set; } = "";
    public double LitersAdded { get; set; }
    public string SupplierName { get; set; } = "";   // IOCL, BPCL, etc.
    public string InvoiceNumber { get; set; } = "";
    public DateTime RefilledAt { get; set; } = DateTime.UtcNow;
}
```

### `src/FuelService/Data/FuelDbContext.cs`
```csharp
using Microsoft.EntityFrameworkCore;
using FuelManagement.FuelService.Models;

namespace FuelManagement.FuelService.Data;

public class FuelDbContext : DbContext
{
    public FuelDbContext(DbContextOptions<FuelDbContext> options) : base(options) { }

    public DbSet<Station> Stations => Set<Station>();
    public DbSet<FuelStock> FuelStocks => Set<FuelStock>();
    public DbSet<FuelRefill> FuelRefills => Set<FuelRefill>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        // Station config
        builder.Entity<Station>(e =>
        {
            e.HasKey(s => s.Id);
            e.HasIndex(s => s.LicenseNumber).IsUnique();
        });

        // FuelStock config
        builder.Entity<FuelStock>(e =>
        {
            e.HasKey(f => f.Id);
            e.HasIndex(f => new { f.StationId, f.FuelType }).IsUnique();
            e.Property(f => f.PricePerLiter).HasPrecision(10, 2);
            e.HasOne(f => f.Station).WithMany().HasForeignKey(f => f.StationId);
        });

        // Seed sample data
        var stationId = Guid.Parse("11111111-1111-1111-1111-111111111111");
        builder.Entity<Station>().HasData(new Station
        {
            Id = stationId,
            Name = "HP Petrol Pump - MG Road",
            Address = "MG Road, Near Metro Station",
            City = "Bangalore",
            State = "Karnataka",
            LicenseNumber = "KA-FUEL-2024-001"
        });

        builder.Entity<FuelStock>().HasData(
            new FuelStock { Id = Guid.NewGuid(), StationId = stationId, FuelType = "Petrol",
                CurrentLiters = 5000, TankCapacity = 10000, PricePerLiter = 103.50m,
                LastRefillDate = DateTime.UtcNow.AddDays(-3) },
            new FuelStock { Id = Guid.NewGuid(), StationId = stationId, FuelType = "Diesel",
                CurrentLiters = 8000, TankCapacity = 15000, PricePerLiter = 89.75m,
                LastRefillDate = DateTime.UtcNow.AddDays(-2) }
        );
    }
}
```

### `src/FuelService/Controllers/StationsController.cs`
```csharp
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FuelManagement.FuelService.Data;
using FuelManagement.FuelService.Models;
using FuelManagement.Shared.DTOs;

namespace FuelManagement.FuelService.Controllers;

[ApiController]
[Route("api/stations")]
public class StationsController : ControllerBase
{
    private readonly FuelDbContext _db;
    public StationsController(FuelDbContext db) => _db = db;

    // GET /api/stations — Anyone can see stations
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? city)
    {
        var query = _db.Stations.Where(s => s.IsActive);
        if (!string.IsNullOrEmpty(city))
            query = query.Where(s => s.City == city);
        return Ok(await query.ToListAsync());
    }

    // GET /api/stations/{id} — Station details with stock
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(Guid id)
    {
        var station = await _db.Stations.FindAsync(id);
        if (station == null) return NotFound();

        var stock = await _db.FuelStocks
            .Where(f => f.StationId == id)
            .ToListAsync();

        return Ok(new { station, fuelStock = stock });
    }

    // POST /api/stations — Admin creates new station
    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create([FromBody] CreateStationDto dto)
    {
        var station = new Station
        {
            Name = dto.Name,
            Address = dto.Address,
            City = dto.City,
            State = dto.State,
            LicenseNumber = dto.LicenseNumber
        };
        _db.Stations.Add(station);

        // Auto-create empty fuel stocks for the new station
        _db.FuelStocks.AddRange(
            new FuelStock { StationId = station.Id, FuelType = "Petrol",
                TankCapacity = 10000, PricePerLiter = 103.50m },
            new FuelStock { StationId = station.Id, FuelType = "Diesel",
                TankCapacity = 15000, PricePerLiter = 89.75m }
        );

        await _db.SaveChangesAsync();
        return Ok(station);
    }
}
```

### `src/FuelService/Controllers/FuelStockController.cs`
```csharp
using MassTransit;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FuelManagement.FuelService.Data;
using FuelManagement.FuelService.Models;
using FuelManagement.Shared.DTOs;
using FuelManagement.Shared.Events;

namespace FuelManagement.FuelService.Controllers;

[ApiController]
[Route("api/fuel-stock")]
[Authorize]
public class FuelStockController : ControllerBase
{
    private readonly FuelDbContext _db;
    private readonly IPublishEndpoint _bus;

    public FuelStockController(FuelDbContext db, IPublishEndpoint bus)
    {
        _db = db;
        _bus = bus;
    }

    // GET /api/fuel-stock/{stationId} — See stock levels
    [HttpGet("{stationId}")]
    public async Task<IActionResult> GetStock(Guid stationId)
    {
        var stock = await _db.FuelStocks
            .Where(f => f.StationId == stationId)
            .ToListAsync();
        return Ok(stock);
    }

    // PUT /api/fuel-stock/{stationId}/refill — Dealer adds fuel delivery
    [HttpPut("{stationId}/refill")]
    [Authorize(Roles = "Dealer,Admin")]
    public async Task<IActionResult> Refill(Guid stationId, [FromBody] RefillStockDto dto)
    {
        // Find the fuel stock
        var stock = await _db.FuelStocks
            .FirstOrDefaultAsync(f => f.StationId == stationId && f.FuelType == dto.FuelType);

        if (stock == null)
            return NotFound(new { message = $"No {dto.FuelType} tank found for this station" });

        // Check tank capacity
        if (stock.CurrentLiters + dto.LitersAdded > stock.TankCapacity)
            return BadRequest(new { message = "Exceeds tank capacity!" });

        // Add fuel
        stock.CurrentLiters += dto.LitersAdded;
        stock.LastRefillDate = DateTime.UtcNow;
        stock.UpdatedAt = DateTime.UtcNow;

        // Record the refill
        _db.FuelRefills.Add(new FuelRefill
        {
            StationId = stationId,
            FuelType = dto.FuelType,
            LitersAdded = dto.LitersAdded,
            SupplierName = dto.SupplierName,
            InvoiceNumber = dto.InvoiceNumber
        });

        await _db.SaveChangesAsync();
        return Ok(new { message = $"Added {dto.LitersAdded}L of {dto.FuelType}", stock });
    }

    // GET /api/fuel-stock/prices — Public fuel prices
    [HttpGet("prices")]
    [AllowAnonymous]
    public async Task<IActionResult> GetPrices()
    {
        var prices = await _db.FuelStocks
            .Include(f => f.Station)
            .Select(f => new {
                StationName = f.Station!.Name,
                City = f.Station.City,
                f.FuelType,
                f.PricePerLiter,
                Available = f.CurrentLiters > 0
            })
            .ToListAsync();
        return Ok(prices);
    }
}
```

### `src/FuelService/Consumers/SaleCreatedConsumer.cs`
```csharp
using MassTransit;
using Microsoft.EntityFrameworkCore;
using FuelManagement.FuelService.Data;
using FuelManagement.Shared.Events;

namespace FuelManagement.FuelService.Consumers;

// THIS IS THE SAGA WORKER!
// When Sales Service creates a sale, this runs automatically
public class SaleCreatedConsumer : IConsumer<SaleCreatedEvent>
{
    private readonly FuelDbContext _db;
    private readonly IPublishEndpoint _bus;
    private readonly ILogger<SaleCreatedConsumer> _logger;

    public SaleCreatedConsumer(FuelDbContext db, IPublishEndpoint bus, ILogger<SaleCreatedConsumer> logger)
    {
        _db = db;
        _bus = bus;
        _logger = logger;
    }

    public async Task Consume(ConsumeContext<SaleCreatedEvent> context)
    {
        var sale = context.Message;
        _logger.LogInformation("⛽ Checking stock for sale {SaleId}: {Liters}L of {FuelType}",
            sale.SaleId, sale.Liters, sale.FuelType);

        // Find the fuel stock
        var stock = await _db.FuelStocks
            .FirstOrDefaultAsync(f => f.StationId == sale.StationId && f.FuelType == sale.FuelType);

        if (stock == null || stock.CurrentLiters < sale.Liters)
        {
            // ❌ NOT ENOUGH FUEL — send failure event
            _logger.LogWarning("❌ Insufficient {FuelType} for sale {SaleId}", sale.FuelType, sale.SaleId);

            await _bus.Publish(new StockInsufficientEvent
            {
                SaleId = sale.SaleId,
                StationId = sale.StationId,
                FuelType = sale.FuelType,
                RequestedLiters = sale.Liters,
                AvailableLiters = stock?.CurrentLiters ?? 0,
                Reason = "Not enough fuel in tank"
            });
            return;
        }

        // ✅ ENOUGH FUEL — deduct stock
        stock.CurrentLiters -= sale.Liters;
        stock.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        _logger.LogInformation("✅ Deducted {Liters}L. Remaining: {Remaining}L",
            sale.Liters, stock.CurrentLiters);

        // Tell Sales Service: stock deducted!
        await _bus.Publish(new StockDeductedEvent
        {
            SaleId = sale.SaleId,
            StationId = sale.StationId,
            FuelType = sale.FuelType,
            LitersDeducted = sale.Liters,
            RemainingStock = stock.CurrentLiters
        });

        // Check if stock is low (below 500L)
        if (stock.CurrentLiters < 500)
        {
            var station = await _db.Stations.FindAsync(sale.StationId);
            await _bus.Publish(new LowStockAlertEvent
            {
                StationId = sale.StationId,
                StationName = station?.Name ?? "",
                FuelType = sale.FuelType,
                CurrentLiters = stock.CurrentLiters,
                DetectedAt = DateTime.UtcNow
            });
        }
    }
}
```

### `src/FuelService/Program.cs`
```csharp
using System.Text;
using MassTransit;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FuelManagement.FuelService.Consumers;
using FuelManagement.FuelService.Data;

var builder = WebApplication.CreateBuilder(args);

// Database
builder.Services.AddDbContext<FuelDbContext>(opt =>
    opt.UseNpgsql(builder.Configuration.GetConnectionString("FuelDb")));

// JWT Auth (same key as Identity Service)
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(opt =>
    {
        opt.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true, ValidateAudience = true,
            ValidateLifetime = true, ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
        };
    });
builder.Services.AddAuthorization();

// RabbitMQ
builder.Services.AddMassTransit(x =>
{
    x.AddConsumer<SaleCreatedConsumer>();  // Listen for sales
    x.UsingRabbitMq((ctx, cfg) =>
    {
        cfg.Host(builder.Configuration["RabbitMq:Host"] ?? "localhost");
        cfg.ConfigureEndpoints(ctx);
    });
});

builder.Services.AddControllers();
builder.Services.AddSwaggerGen();

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<FuelDbContext>();
    db.Database.Migrate();
}
app.UseSwagger(); app.UseSwaggerUI();
app.UseAuthentication(); app.UseAuthorization();
app.MapControllers();
app.Run();
```

### `src/FuelService/appsettings.json`
```json
{
  "ConnectionStrings": {
    "FuelDb": "Host=localhost;Port=5432;Database=FuelDb;Username=postgres;Password=postgres"
  },
  "Jwt": {
    "Key": "FuelManagementSecretKey12345678!",
    "Issuer": "FuelManagement",
    "Audience": "FuelManagementUsers"
  },
  "RabbitMq": { "Host": "localhost" }
}
```
