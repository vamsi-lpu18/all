namespace design_pat.Models
{
    public class StudentModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public int m1 { get; set; }
        public int m2 { get; set; }
       
    }
}